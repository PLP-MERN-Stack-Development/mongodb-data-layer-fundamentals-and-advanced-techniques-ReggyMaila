use("plp_bookstore");

db.books.insertMany([
  {
    title: "The Pragmatic Programmer",
    author: "Andrew Hunt",
    genre: "Technology",
    published_year: 1999,
    price: 45.5,
    in_stock: true,
    pages: 352,
    publisher: "Addison-Wesley"
  },
  {
    title: "Clean Code",
    author: "Robert C. Martin",
    genre: "Technology",
    published_year: 2008,
    price: 50.0,
    in_stock: true,
    pages: 464,
    publisher: "Prentice Hall"
  },
  {
    title: "Atomic Habits",
    author: "James Clear",
    genre: "Self-Help",
    published_year: 2018,
    price: 25.0,
    in_stock: true,
    pages: 320,
    publisher: "Penguin"
  },
  {
    title: "1984",
    author: "George Orwell",
    genre: "Fiction",
    published_year: 1949,
    price: 15.0,
    in_stock: false,
    pages: 328,
    publisher: "Secker & Warburg"
  },
  {
    title: "Sapiens",
    author: "Yuval Noah Harari",
    genre: "History",
    published_year: 2011,
    price: 35.0,
    in_stock: true,
    pages: 498,
    publisher: "Harper"
  },
  {
    title: "Educated",
    author: "Tara Westover",
    genre: "Memoir",
    published_year: 2018,
    price: 30.0,
    in_stock: true,
    pages: 352,
    publisher: "Random House"
  },
  {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    genre: "Fiction",
    published_year: 1960,
    price: 20.0,
    in_stock: true,
    pages: 281,
    publisher: "J.B. Lippincott & Co."
  },
  {
    title: "The Alchemist",
    author: "Paulo Coelho",
    genre: "Fiction",
    published_year: 1988,
    price: 22.5,
    in_stock: true,
    pages: 208,
    publisher: "HarperOne"
  },
  {
    title: "Deep Work",
    author: "Cal Newport",
    genre: "Self-Help",
    published_year: 2016,
    price: 28.0,
    in_stock: false,
    pages: 296,
    publisher: "Grand Central"
  },
  {
    title: "Becoming",
    author: "Michelle Obama",
    genre: "Biography",
    published_year: 2018,
    price: 32.0,
    in_stock: true,
    pages: 448,
    publisher: "Crown"
  }
]);
