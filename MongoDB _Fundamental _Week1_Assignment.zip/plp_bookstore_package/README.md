# 📚 PLP Bookstore – MongoDB Week 1

## Objective
Learn MongoDB fundamentals, CRUD, aggregation, and indexing using a bookstore dataset.

## Setup Instructions
1. Clone this repository:
   ```bash
   git clone 
   cd plp_bookstore
   ```
2. Open `mongosh` or MongoDB Compass.
3. Run the insert script:
   ```bash
   load("insert_books.js")
   ```
4. Execute queries from:
   ```bash
   load("queries.js")
   ```

## Files
- `insert_books.js`: Inserts book data into the `books` collection.
- `queries.js`: Contains all MongoDB queries and aggregation pipelines.
- `screenshots/compass_screenshot.png`: Visual proof of collection setup.

## Tools Used
- MongoDB Atlas / MongoDB Community Edition
- MongoDB Compass
- MongoDB Shell (mongosh)


