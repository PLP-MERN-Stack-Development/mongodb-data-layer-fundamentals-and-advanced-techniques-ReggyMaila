const { MongoClient } = require("mongodb");

const uri = "mongodb+srv://reginaldmokagane_db_user:<Password02>@cluster0.7alsnmr.mongodb.net/Plp_bookstore?appName=Cluster0";

const books = [
  { title: "The Pragmatic Programmer", author: "Andrew Hunt", genre: "Technology", published_year: 1999, price: 45.5, in_stock: true, pages: 352, publisher: "Addison-Wesley" },
  { title: "Clean Code", author: "Robert C. Martin", genre: "Technology", published_year: 2008, price: 50.0, in_stock: true, pages: 464, publisher: "Prentice Hall" },
  { title: "Atomic Habits", author: "James Clear", genre: "Self-Help", published_year: 2018, price: 25.0, in_stock: true, pages: 320, publisher: "Penguin" },
  // ... add more if needed
];

async function main() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db("plp_bookstore");
    const result = await db.collection("books").insertMany(books);
    console.log(`✅ Inserted ${result.insertedCount} books`);
  } catch (err) {
    console.error(err);
  } finally {
    await client.close();
  }
}

main();

